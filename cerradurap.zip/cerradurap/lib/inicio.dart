import 'package:cerradurap/segundo.dart';
import 'package:flutter/material.dart';
import 'package:cerradurap/principio.dart';

class Uno extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
        title: Text('Cerradura Electrónica'),
    backgroundColor: Colors.cyanAccent,
    ),
    body: Center(
      child: Column(
        children: [
          SizedBox(height: 30,),
          Container(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[RaisedButton(
                  child: Text("Inicio"), color: Colors.amber,onPressed:() {
                    final ruta = MaterialPageRoute(builder: (context) {return Inicio();},);
                    Navigator.push(context, ruta);
              },),
              SizedBox(height: 20,),
              RaisedButton(
                  child: Text("Segundo"),
                  color: Colors.amberAccent,
                  onPressed: (){
                    final ruta = MaterialPageRoute(builder: (context){return Segundo();},);
                  Navigator.push(context, ruta);
                    },),
              ],
            ),
          )
        ],
      ),
    ),
    );
  }

}