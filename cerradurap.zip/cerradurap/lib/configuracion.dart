import 'package:flutter/material.dart';

class Configuracion extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: Text('Configuración'),
    ),
    body: Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          SizedBox(height: 18,),
          Container(height: 277, width: 500, color: Colors.cyanAccent,
          child: Text('Configuracion de cerradura'),),
        ],
      ),
    ),
    floatingActionButton: Row(
      children: <Widget>[
        Expanded(child: SizedBox(),),
        FloatingActionButton(heroTag: 'btn2', child: Icon(Icons.home),onPressed: () {Navigator.pushNamed(context, 'Inicio');},),
      ],
    ),
    );
  }

}