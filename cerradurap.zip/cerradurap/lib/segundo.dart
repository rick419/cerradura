import 'package:flutter/material.dart';

class Segundo extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
  return Scaffold(
    appBar: AppBar(title: Text('Pantalla de registros'),
    backgroundColor: Colors.cyanAccent,),
  body: Center(
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[Text('Registro')],
    ),
  ),
  floatingActionButton: Row(
    children: <Widget>[
      Expanded(
        child: SizedBox(),
      ),
      FloatingActionButton(
          heroTag: 'btn1',
          child: Icon(Icons.home),
          onPressed: (){
            Navigator.pushNamed(context, 'Inicio');
          },),
      SizedBox(width: 36,),
      FloatingActionButton(onPressed: (){Navigator.pushNamed(context, 'Configuración');},),
    ],
  ),
  );
  }

}