import 'package:flutter/material.dart';

class Inicio extends StatefulWidget{
  @override
  State<Inicio> createState()=> _Inicio();
}

class _Inicio extends State<Inicio>{
  bool isSwitched=false;
  String activar="Activado";
  String desactivar="Desactivado";

  @override
  Widget build(BuildContext context) {
  return Scaffold(
    appBar: AppBar(
      title: Text('Inicio'),
      backgroundColor: Colors.cyanAccent,
    ),
    body: Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[Text('Presionar para activar'),
        Text(activar),
        Switch(value: isSwitched, onChanged: (value){
          setState(() {
            isSwitched=value;
            if(value){desactivar="Activar";}else{desactivar="Desactivar";}
            activar=desactivar;
          });
        },
          activeTrackColor: Colors.lightBlueAccent,
          activeColor: Colors.blue,
        ),
        ],
      ),
    ),
    floatingActionButton: Row(
      children: <Widget>[
        Expanded(
          child: SizedBox(),
        ),
        FloatingActionButton(
            heroTag: 'bTnI',
            child: Icon(Icons.account_circle_rounded),
            backgroundColor: Colors.cyan,
            onPressed: (){
              Navigator.pushNamed(context, "Inicio");
            })
      ],
    ),
  );
  }

}