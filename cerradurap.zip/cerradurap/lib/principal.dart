import 'package:cerradurap/inicio.dart';
import 'package:cerradurap/principio.dart';
import 'package:cerradurap/segundo.dart';
import 'package:cerradurap/configuracion.dart';
import 'package:flutter/material.dart';

class Cerradura extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      initialRoute: '/',
      routes: <String, WidgetBuilder>{
        '/': (BuildContext context) => Inicio(),
        'principio': (BuildContext context) => Uno(),
        'segundo' : (BuildContext context) => Segundo(),
        'configuracion' : (BuildContext context) => Configuracion(),
        'inicio' : (BuildContext context) => Inicio(),
      },
    );
  }

}