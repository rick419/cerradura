import 'package:flutter/material.dart';
import 'package:cerradurap/principal.dart';

void main() {
  runApp(Cerradura());
}